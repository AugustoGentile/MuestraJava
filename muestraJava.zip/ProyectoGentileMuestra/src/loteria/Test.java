package loteria;

import java.util.Scanner;

public class Test {
	private static Scanner input = new Scanner(System.in); // cerrar el scanner

	public static void main(String[] args) {

		Agencia agencia = new Agencia();

		System.out.println("Bienvenido!");
		while (cargaVenta()) {
			int dni = ingreseDNI();
			int tipo = ingreseTipoBoleta();
			int valor = ingreseValor(tipo);

			Boleta boleta = new Boleta(tipo, dni, valor);

			agencia.altaBoleta(boleta);
		}

		System.out.println("--- Ingreso de ventas finalizado ---");

		if (agencia.getBoletasVendidas() == 0)
			System.out.println("No se ha ingresado ninguna venta.");
		else {
			System.out.println("Cantidad de boletas vendidas: " + agencia.getBoletasVendidas());
			System.out.println("Total recaudado: $" + agencia.getTotRecaudado());
			System.out.println("Promedio del monto obtenido por ventas de boleta tipo 2: " + agencia.obtenerPromTipo2());
			System.out.println("Boleta de mayor monto vendida: " + agencia.getBoletaMayorMonto());
		}
	}

	public static boolean cargaVenta() {
		String respuesta;
		boolean venta = false;

		System.out.println("Desea cargar alguna venta? Ingrese �s� o �n�");
		respuesta = input.nextLine();

		while (!respuesta.equals("s") && !respuesta.equals("n")) {
			System.out.println("Desea cargar alguna venta? Ingrese �s� o �n�");
			respuesta = input.nextLine();

		}
		if (respuesta.equals("s"))
			venta = true;
		return venta;
	}

	public static int ingreseTipoBoleta() {
		int tipo = 0;
		while (tipo != 1 && tipo != 2) {
			System.out.print("Ingrese el tipo de boleta(1/2): ");
			tipo = input.nextInt();
			input.nextLine();
		}
		return tipo;
	}

	public static int ingreseDNI() {
		int dni;
		System.out.print("Ingrese el DNI del ofertante: ");
		do {
			dni = input.nextInt();
		} while (dni == 0);
		return dni;
	}

	public static int ingreseValor(int tipo) {
		int valor = 0;
		do {
			System.out.print("Ingrese el monto para su boleta (M�ximo $50): ");
			valor = input.nextInt();
			input.nextLine();
		} while (!Boleta.validarBoleta(tipo, valor));
		return valor;
	}

}
