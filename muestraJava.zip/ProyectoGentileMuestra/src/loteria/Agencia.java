package loteria;

public class Agencia {

	private int boletasVendidas;
	private double totRecaudado;
	private Boleta boletaMayorMonto;
	private double tipo2TotRecaudado;
	private int boletasVendidasTipo2;

	public Agencia() { // constructor
		this.boletasVendidas = 0;
		this.totRecaudado = 0;
		this.boletaMayorMonto = new Boleta();
		this.tipo2TotRecaudado = 0;
		this.boletasVendidasTipo2 = 0;
	}

	public void altaBoleta(Boleta boleta) {
		this.boletasVendidas++;
		this.totRecaudado += boleta.getValor();
		if (this.boletaMayorMonto.getValor() < boleta.getValor()) {
			this.boletaMayorMonto = boleta;
		}
		if (boleta.getTipo() == 2) {
			this.boletasVendidasTipo2++;
			this.tipo2TotRecaudado += boleta.getValor();
		}
	}

	public double obtenerPromTipo2() { // ver como aplico decimal format lib
		double promedio = 0;
		if (this.boletasVendidasTipo2 > 0) {
			promedio = this.boletasVendidasTipo2 / this.tipo2TotRecaudado;
		} else {
			System.out.println("Aun no se venden boletas del tipo 2");
			promedio = 0;
		}
		return promedio;
	}

	public int getBoletasVendidas() {
		return boletasVendidas;
	}

	public void setBoletasVendidas(int boletasVendidas) {
		this.boletasVendidas = boletasVendidas;
	}

	public double getTotRecaudado() {
		return totRecaudado;
	}

	public void setTotRecaudado(int totRecaudado) {
		this.totRecaudado = totRecaudado;
	}

	public Boleta getBoletaMayorMonto() {
		return boletaMayorMonto;
	}

	public void setBoletaMayorMonto(Boleta boletaMayorMonto) {
		this.boletaMayorMonto = boletaMayorMonto;
	}

	public double getTipo2TotRecaudado() {
		return tipo2TotRecaudado;
	}

	public void setTipo2TotRecaudado(int tipo2TotRecaudado) {
		this.tipo2TotRecaudado = tipo2TotRecaudado;
	}

	public int getBoletasVendidasTipo2() {
		return boletasVendidasTipo2;
	}

	public void setBoletasVendidasTipo2(int boletasVendidasTipo2) {
		this.boletasVendidasTipo2 = boletasVendidasTipo2;
	}
}
