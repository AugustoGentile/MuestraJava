package loteria;

public class Boleta {
	private String nombreTipo;
	private int tipo;
	private int valor;
	private int dni;
	static final int MONTO_MAX = 50;
	static final String TIPO1 = "Boleta Ciudad";
	static final String TIPO2 = "Boleta Provincial";

	public Boleta() {
		this.nombreTipo = "";
		this.tipo = 0;
		this.dni = 0;
	}

	public Boleta(int tipo, int dni, int valor) { // constructor parametrizado
		this.setTipo(tipo);
		this.dni = dni;
		this.valor = valor;
	}

	public static boolean validarBoleta(int tipo, int valor) {
		boolean boletaValida = false;
		if (valor > 0 && valor <= MONTO_MAX) {
			boletaValida = true;
		}
		return boletaValida;
	}

	public String getNombreTipo() {
		return nombreTipo;
	}

	public void setNombreCliente(String nombreCliente) {
		this.nombreTipo = nombreTipo;
	}

	public int getTipo() {
		return tipo;
	}

	public void setTipo(int tipo) {
		this.tipo = tipo;
		if (tipo == 1) {
			this.nombreTipo = TIPO1;
		}
		if (tipo == 2) {
			this.nombreTipo = TIPO2;
		}
	}

	public int getValor() {
		return valor;
	}

	public void setValor(int valor) {
		this.valor = valor;
	}

	public int getDni() {
		return dni;
	}

	public void setDni(int dni) {
		this.dni = dni;
	}

	@Override
	public String toString() {
		return "Boleta [nombreTipo=" + nombreTipo + ", tipo=" + tipo + ", valor=" + valor + ", dni=" + dni + "]";
	}
}
